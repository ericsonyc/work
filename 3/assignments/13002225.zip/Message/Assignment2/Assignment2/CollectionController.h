//
//  CollectionController.h
//  Assignment2
//
//  Created by ericson on 16/5/4.
//  Copyright © 2016年 student. All rights reserved.
//

#ifndef CollectionController_h
#define CollectionController_h

#import <UIKit/UIKit.h>
@interface CollectionController : UITableViewController

@property NSMutableArray *messageDatas;
@property (nonatomic,strong) UIButton *addBtn;
@end

#endif /* CollectionController_h */
