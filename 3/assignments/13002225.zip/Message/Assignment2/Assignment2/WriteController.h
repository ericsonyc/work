
#ifndef WriteController_h
#define WriteController_h

#import <UIKit/UIKit.h>

@interface WriteController : UITableViewController

@end

#endif /* WriteController_h */
