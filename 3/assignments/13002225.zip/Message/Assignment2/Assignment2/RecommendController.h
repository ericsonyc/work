
#ifndef RecommendController_h
#define RecommendController_h

#import <UIKit/UIKit.h>
@interface RecommendController : UITableViewController

@property NSMutableArray *messageDatas;
@end

#endif /* RecommendController_h */
