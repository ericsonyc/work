#import <UIKit/UIKit.h>

@interface CTCollectionView : UICollectionView<UIScrollViewDelegate>

@end
