

#import <UIKit/UIKit.h>

@interface CTHeadViewCell : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UILabel *courseNum;

@end
