

#import <UIKit/UIKit.h>

@interface CTWeekView : UIView

@end
