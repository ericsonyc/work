//
//  Plan.h
//  Assignment1
//
//  Created by ericson on 16/5/2.
//  Copyright © 2016年 student. All rights reserved.
//

#ifndef Plan_h
#define Plan_h

#import <UIKit/UIKit.h>

@interface Plan : UIViewController

@property (strong,nonatomic) UITextView *textView;

@end

#endif /* Plan_h */
