

#import <UIKit/UIKit.h>

@interface CTDayViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *courseNum;
@property (weak, nonatomic) IBOutlet UILabel *courseName;
@property (weak, nonatomic) IBOutlet UILabel *courseAddress;
@property (weak, nonatomic) IBOutlet UILabel *coursePeriod;

@end
