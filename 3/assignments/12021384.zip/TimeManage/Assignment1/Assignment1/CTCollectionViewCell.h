

#import <UIKit/UIKit.h>
#import "CTCourseInfo.h"

@interface CTCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) UILabel *courseName;

@end
