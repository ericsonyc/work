

#import "CTCourseInfo.h"

@implementation CTCourseInfo

-(void)initWithZero{
    self.courseAddress = @"";
    self.courseName = @"";
    self.coursePeriod = @"";
}

@end
