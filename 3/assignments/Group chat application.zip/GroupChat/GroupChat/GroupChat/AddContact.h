
#ifndef AddContact_h
#define AddContact_h

#import <UIKit/UIKit.h>

@interface AddContact: UIView

@property (nonatomic,strong) IBOutlet UITextView *message;
@property (nonatomic,strong) IBOutlet UIButton *addBtn;

@end

#endif /* AddContact_h */
