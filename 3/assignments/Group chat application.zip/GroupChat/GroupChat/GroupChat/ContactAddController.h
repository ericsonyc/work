
#ifndef ContactAddController_h
#define ContactAddController_h
#import<UIKit/UIKit.h>
#import "AddContact.h"
@interface ContactAddController : UIViewController

@property (nonatomic,strong) AddContact *contact;
@end

#endif /* ContactAddController_h */
