
#ifndef SearchView_h
#define SearchView_h

#import <UIKit/UIKit.h>

@interface SearchView : UIView

@property (nonatomic,strong) IBOutlet UISearchBar *searchBar;
@property (nonatomic,strong) IBOutlet UIButton *addBtn;

@end

#endif /* SearchView_h */
