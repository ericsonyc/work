
#import <UIKit/UIKit.h>
#import "AddView.h"
@interface AddController : UIViewController

@property (nonatomic,strong) AddView *addview;

@end
