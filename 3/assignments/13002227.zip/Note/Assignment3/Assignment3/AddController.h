//
//  AddController.h
//  Assignment3
//
//  Created by ericson on 16/5/5.
//  Copyright © 2016年 student. All rights reserved.
//

#ifndef AddController_h
#define AddController_h

#import <UIKit/UIKit.h>
#import "InputView.h"

@interface AddController : UIViewController

@property (nonatomic,retain) InputView *inputView;

@end

#endif /* AddController_h */
