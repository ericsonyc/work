//
//  Message.m
//  Assignment3
//
//  Created by ericson on 16/5/5.
//  Copyright © 2016年 student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Message.h"

@implementation Message

-(id)initWithName:(NSString *)mm{
    self.name=mm;
    return self;
}

@end